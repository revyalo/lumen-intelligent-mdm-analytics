# Lumen — Data intelligence evidence report

All business data are synthetic. No causal or production-performance claims.

## Reproduction

```json
{
  "company": "Lumen Distribution",
  "size": "demo",
  "seed": 42,
  "as_of": "2026-09-30",
  "currency": "EUR",
  "period_start": "2024-10-01",
  "period_end": "2026-09-30",
  "generator_version": 1,
  "synthetic": true,
  "analysis_table": "customer_sources",
  "analysis_rows": 252,
  "report_scope": "Selected original table plus full supplied relational bundle",
  "versions": {
    "pandas": "2.3.3",
    "numpy": "2.5.4",
    "duckdb": "1.5.6",
    "scikit-learn": "1.9.1",
    "rapidfuzz": "3.14.6"
  }
}
```

## Business metrics

- revenue: 1192155.2799999998
- orders: 1321
- customers: 120
- active_customers: 78
- inactive_customers: 42
- average_order: 902.4642543527629
- top20_share: 0.6988348447359981
- active_days: 180
- as_of: 2026-09-30

## Analytical observations

### Customer revenue is concentrated

Evidence: {"top_20_pct_share": 0.6988348447359981, "customer_accounts": 120, "revenue_eur": 1192155.2799999998}

Method: Revenue rank; top ceil(20% × all customer accounts), fulfilled orders only

Limitations: Descriptive synthetic data; concentration is undefined when revenue is zero

Action to investigate: Review dependency on large accounts and investigate retention priorities

### Missing email addresses in sales

Evidence: {"missing": 24, "rows": 120, "missing_pct": 20.0}

Method: Missing-cell count in original customer-source records

Limitations: Syntax-valid addresses are not verified contacts; blanks from external data need normalization

Action to investigate: Ask the source owner to validate and recover contacts from authoritative records

### Latest observed month changed materially

Evidence: {"month": "2026-09-01", "revenue_eur": 61961.15000000001, "previous_revenue_eur": 45383.43, "mom_pct": 36.52813372634023}

Method: 100 × (current/prior − 1); rule threshold |20%|

Limitations: Calendar composition, constructed seasonality and partial periods can explain changes

Action to investigate: Compare equivalent full periods and category mix before acting

### Some purchasing accounts have aged beyond the recency threshold

Evidence: {"at_risk": 21, "customers": 120, "recency_days_threshold": 180}

Method: RFM: last 365 days; >180 days since last fulfilled purchase

Limitations: No purchases in the window are a separate segment; purchase cadence varies by business

Action to investigate: Validate expected purchasing cadence before designing a reactivation campaign

## Quality and transformations

Original score: 78.1096903782089; normalized: 83.83548892808152.
245 cell changes logged. Source rows are preserved. Rules/denominators are in quality_rules_*.csv.

## Methods and limits

Statistics use finite values and sample standard deviation. IQR/z-scores and ML flags require investigation.
Revenue counts fulfilled invoices; active customers use the final 180 days. RFM uses the final 365 days.
Synthetic margins use historical line costs. Quality excludes nonapplicable dimensions; scores are diagnostic.
Matching scores are heuristic similarities. No automatic merges occur. Embeddings and forecasting are not part of this report.
See docs/METHODOLOGY.md in the source project for exact definitions and limitations.